file_input=open("/content/drive/MyDrive/cse221_labs/Lab_5/input1.txt","r")
file_output=open("/content/drive/MyDrive/cse221_labs/Lab_5/output1a.txt","w")
content=file_input.readlines()
connections=content[1:]
graph={}
for i in connections:
  i=i.split()
  if int(i[0]) not in graph.keys():
    graph[int(i[0])]=[]
  if int(i[1]) not in graph.keys():
    graph[int(i[1])]=[]
  graph[int(i[0])].append(int(i[1]))
#cycle detection code
colour={}
parent={}
result="No"
for i in graph.keys():
  colour[i]="w"
  parent[i]="None"
def dfs_cycle_detect(u):
  global result
  colour[u]= "g"
  for i in graph[u]:
    if colour[i] == "w":
        parent[i]=u
        dfs_cycle_detect(i)
    if colour[i]== "g":
      result="yes"  
  colour[u]="B"
def dfs(graph,visited,node,stack):
  visited.add(node)
  for child in graph[node]:
    if child not in visited:
      #stack.append(child)
      dfs(graph,visited,child,stack)
  stack.append(node)
def top_sort_dfs(graph):
  for node in graph:
    dfs_cycle_detect(node)
    break
  if result=="yes":
    return "IMPOSSIBLE"
  visited=set()
  stack=[]
  for node in graph:
    
    #print("node:",node)
    if node not in visited:
      dfs(graph,visited,node,stack)
  return (str(stack[::-1])[1:-1]).replace(","," ")
#print(graph)"""
for node in graph:
  dfs_cycle_detect(node)
if result=="yes":
  file_output.write("Impossible")
  #print("Impossible")
else:
  top_sort=top_sort_dfs(graph)
  file_output.write(top_sort)
  #print(top_sort)