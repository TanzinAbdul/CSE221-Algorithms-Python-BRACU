######################## task 1b #########################
from collections import deque
file_input=open("/content/drive/MyDrive/cse221_labs/Lab_5/input1.txt","r")
file_output=open("/content/drive/MyDrive/cse221_labs/Lab_5/output1b.txt","w")
content=file_input.readlines()
connections=content[1:]
#print(connections)
graph={}
indegree={}
for i in connections:
  i=list(map(int,i.split()))
 ## print(i)
  if i[0] not in graph.keys():
    graph[i[0]]=[]
    indegree[i[0]]=0
  if i[1] not in graph.keys():
    graph[i[1]]=[]
    indegree[i[1]]=0
  graph[i[0]].append(i[1])
  indegree[i[1]]=indegree[i[1]]+1
#cycle detection code
#print(graph)
#print(indegree)
colour={}
parent={}
result="No"
for i in graph.keys():
  colour[i]="w"
  parent[i]="None"
def dfs_cycle_detect(u):
  global result
  colour[u]= "g"
  for i in graph[u]:
    if colour[i] == "w":
        parent[i]=u
        dfs_cycle_detect(i)
    if colour[i]== "g":
      result="yes"
  colour[u]="B"
queue=deque([])
def bfs_toposort():
    global queue
    result=[]
    for node in indegree:
       # print(node)
        if indegree[node]==0:
            queue.append(node)
            indegree[node]-=1 ### as we can not del key from dic 
    #temp=queue.popleft()         making it -1 so that it will never become zero again
    while queue:
        temp=queue.popleft()
        result.append(temp)
        for node in graph[temp]:
            indegree[node]-=1
        for node in indegree:
            if indegree[node]==0:
                queue.append(node)
                indegree[node]-=1
    return result
for node in graph:
  dfs_cycle_detect(node)
  if result=="yes":
    file_output.write("Impossible")
    break
if result=="No":
  result=bfs_toposort()
  result=str(result)[1:-1].replace(","," ")
  file_output.write(result)
