##########################  task 3 ##############
file_input=open("/content/drive/MyDrive/cse221_labs/Lab_5/input3.txt","r")
file_output=open("/content/drive/MyDrive/cse221_labs/Lab_5/output3.txt","w")
content=file_input.readlines()
ttl_nodes=int(content[0][0])
connections=content[1:]
graph={}
start_time_graph={}
end_time_graph={}
graph_reverse={}
time=1
lst=[]
visited=set()
#start_time_graph_reverse={}
################################ initialization of dictionary #################
for i in range(1,ttl_nodes+1):
  graph[i]=[]
  graph_reverse[i]=[]
  start_time_graph[i]=None
  end_time_graph[i]=None
  #start_time_graph_reverse[i]=[]
################################ making graph/reverse graph  #######################
for i in connections:
  i=i.split()
  graph[int(i[0])].append(int(i[1]))
  graph_reverse[int(i[1])].append(int(i[0]))
################################ making dfs funciton ######################
def dfs(graph,node,visited):
  global time
  visited.add(node)
  start_time_graph[node]=time
  time+=1
  for child in graph[node]:
    if child not in visited:
      dfs(graph,child,visited)
  end_time_graph[node]=time
  time+=1
################################# making scc functionn #############
def scc(graph,node,visited):
  global time
  global lst
  visited.add(node)
  start_time_graph[node]=time
  time+=1
  for child in graph[node]:
    if child not in visited:
      scc(graph,child,visited)
  end_time_graph[node]=time
  lst.append(node)
  time+=1
################################ calling dfs function for given graph ################
for node in graph:
  if node not in visited:
    dfs(graph,node,visited)
################################ sorting end time in descendng  order ##############
sorted_end_time_graph= dict(sorted(end_time_graph.items(), key=lambda item: item[1], reverse=True))
################################ calling ssc in reversed graph ###############
visited=set()
time=1
ssc_lst=[]
for node in sorted_end_time_graph:
  if node not in visited:
    scc(graph_reverse,node,visited)
    ssc_lst.append(lst)
    lst=[]
for i in ssc_lst:
  file_output.write((str(i)[1:-1]).replace(","," "))
  file_output.write("\n")