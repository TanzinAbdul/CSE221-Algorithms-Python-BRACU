
file1 = open('input2.txt','r')
file2 = open('output2.txt','w')

n = int(file1.readline())


def stairs_count(n):
    
    array = [0] * (n + 1)
    
    array[0] = 1
    array[1] = 1
    
    for i in range(2, n + 1):
        array[i] = array[i - 1] + array[i - 2]
    
    return array[n]


file2.write(str(stairs_count(n)))

file1.close()
file2.close()
