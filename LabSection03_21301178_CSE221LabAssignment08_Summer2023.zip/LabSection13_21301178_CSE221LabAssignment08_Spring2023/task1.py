class find_num_class:
    
    def __init__(self, variable_1):
        self.high_road = list(range(variable_1))
        self.count_rank = [0] * variable_1

    def cities(self, x):
        
        if self.high_road[x] != x:
            self.high_road[x] = self.cities(self.high_road[x])
        
        return self.high_road[x]

    def roads(self, x, y):
        road_1 = self.cities(x)
        road_2 = self.cities(y)

        if road_1 == road_2:
            return False

        if self.count_rank[road_1] < self.count_rank[road_2]:
            road_1, road_2 = road_2, road_1

        self.high_road[road_2] = road_1
        
        if self.count_rank[road_1] == self.count_rank[road_2]:
            self.count_rank[road_1] += 1

        return True


file1 = open('input1.txt','r')
file2 = open('output1.txt','w')

n, m = map(int, file1.readline().split())
edges = []

for variable_2 in range(m):
    
    road_a, road_b, road_c = map(int, file1.readline().split())
    
    edges.append((road_c, road_a - 1, road_b - 1))

edges.sort()

func_call = find_num_class(n)

weig_count = 0
edge_count = []

for road_c, road_a, road_b in edges:

    if func_call.roads(road_a, road_b):

        weig_count += road_c
        edge_count.append((road_a, road_b))


find_cost = float('inf')

for road_a, road_b in edge_count:

    func_call = find_num_class(n)

    after_con_edge = 0
    
    for road_c, var3, var4 in edges:
    
        if (var3, var4) == (road_a, road_b) or (var3, var4) == (road_b, road_a):
            continue
    
        if func_call.roads(var3, var4):
            after_con_edge += road_c

    decrease_cost = weig_count - after_con_edge
    
    if decrease_cost < find_cost:
        find_cost = decrease_cost


file2.write(str(weig_count - find_cost))

file1.close()
file2.close()