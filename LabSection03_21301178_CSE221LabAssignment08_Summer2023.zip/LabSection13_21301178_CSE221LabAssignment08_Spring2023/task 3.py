def count_min_coin(coins, giv_amount):
    # Create a list of size amount+1 to store minimum coins required for each value from 0 to amount
    temp_dp = [float('inf')] * (giv_amount + 1)
    # Minimum coins required to make up 0 is 0
    temp_dp[0] = 0

    # Loop through all possible values from 1 to amount
    for i in range(1, giv_amount + 1):
        # Loop through all coins and check if the current coin can be used to make up the current value
        for j in range(len(coins)):
            if coins[j] <= i:
                # If the current coin can be used, update the minimum coins required
                temp_dp[i] = min(temp_dp[i], temp_dp[i - coins[j]] + 1)

    # If the minimum coins required for the target amount is still infinite, it means it cannot be made up
    if temp_dp[giv_amount] == float('inf'):
        return -1
    else:
        return temp_dp[giv_amount]


input_file = open('task 3 input.txt', mode='r', encoding='utf-8-sig')
output_file = open('task 3 output.txt', mode='w')
n, x = map(int, input_file.readline().strip('\n').split())
coins = list(map(int, input_file.readline().split()))
output_file.write(count_min_coin(coins, x))

