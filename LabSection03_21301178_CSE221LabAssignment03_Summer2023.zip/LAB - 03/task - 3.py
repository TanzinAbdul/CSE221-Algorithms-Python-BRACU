def partition(arr, start, end):
    i = start - 1
    for j in range(start, end):
        if arr[j] < arr[end]:
            i += 1
            (arr[i], arr[j]) = (arr[j], arr[i])
    (arr[i + 1], arr[end]) = (arr[end], arr[i + 1])
    return i + 1


def quicksort(array, start, end):
    if start <= end:
        part = partition(array, start, end)
        quicksort(array, start, part - 1)
        quicksort(array, part + 1, end)


array = list(map(int, open('input - 3.txt', mode='r', encoding='utf-8-sig').readline().split(', ')))
quicksort(array, 0, len(array) - 1)
file_output = open('output - 3.txt', mode='w')
print(array)
file_output.write(str(array))

