file_input = open('input - 2.txt', mode='r', encoding='utf-8-sig')
file_output = open('output - 2.txt', mode='w')
n = file_input.readline()
temp_list = list(map(int, file_input.readline().strip().split(' ')))

def get_cross_max(arr):
    best_left_number = max(arr[:len(arr)//2])
    temp_arr = []
    for i in range(len(arr)//2, len(arr)):
        temp_arr.append(arr[i]**2)
    best_right_number = max(temp_arr)
    return best_left_number + best_right_number


def get_max(arr):
    if len(arr) == 1:
        return float('-inf')
    if len(arr) == 2:
        return arr[0] + arr[1]**2

    left_max = get_max(arr[:len(arr)//2])
    right_max = get_max(arr[len(arr)//2:])

    cross_max = get_cross_max(arr)
    #print(left_max, right_max, cross_max)
    return max(left_max, right_max, cross_max)

print(get_max(temp_list))

