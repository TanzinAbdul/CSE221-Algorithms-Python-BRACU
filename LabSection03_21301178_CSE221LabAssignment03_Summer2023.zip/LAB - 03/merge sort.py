file_input = open('input - 1.txt', mode='r', encoding='utf-8-sig')
file_output = open('output - 1.txt', mode='w')

n = int(file_input.readline())
alien_list = list(map(int, file_input.readline().strip('\n').split(' ')))
print(alien_list)

def compare(arr_1, arr_2):
    i = 0
    j = 0
    k = 0
    new_size = len(arr_1) + len(arr_2)
    new_arr = [0]*new_size

    for k in range(new_size):
        # print(k, i, j)
        if i < len(arr_1) and j < len(arr_2):
            if arr_1[i] > arr_2[j]:
                new_arr[k] = arr_1[i]
                i += 1
            else:
                new_arr[k] = arr_2[j]
                j += 1
        else:
            break
    # print(new_arr)
    # print(k)
    if i < len(arr_1):
        for l in range(k, new_size):
            new_arr[l] = arr_1[i]
            i += 1
    elif j < len(arr_2):
        for l in range(k, new_size):
            new_arr[l] = arr_2[j]
            j += 1
    # print(new_arr)

    return new_arr


def divide(array):
    if len(array) == 1:
        return array
    else:
        mid = len(array)//2
        left_arr = divide(array[:mid])
        right_arr = divide(array[mid:])
        return compare(left_arr, right_arr)



print(divide(alien_list))