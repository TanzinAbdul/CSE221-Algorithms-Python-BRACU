file_input = open('input - 4.txt', mode='r', encoding='utf-8-sig')
file_output = open('output - 4.txt', mode='w')
n = file_input.readline()
array = list(map(int, file_input.readline().strip('\n').split(' ')))
queries = int(file_input.readline())
print(array)
def Partition(array, pivot, r):
    i = 0
    arr = array.copy()
    arr[0], arr[arr.index(pivot)] = arr[arr.index(pivot)], arr[0]
    for j in range(1, r):
        if pivot > arr[j]:
            i += 1
            #arr[j], arr[i] = arr[i], arr[j]

    #arr[i], arr[pivot] = arr[pivot], arr[i]
    return i+1

for k in range(queries):
    kth_small = int(file_input.readline().strip('\n'))
    for i in range(len(array)):
        position = Partition(array, array[i], len(array))
        if kth_small == position:
            print(array[i])
            file_output.write(str(array[i]))
            break

