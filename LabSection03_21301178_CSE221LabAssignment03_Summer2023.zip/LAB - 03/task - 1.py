input_file = open("input - 1.txt", mode='r', encoding='utf-8-sig')
# input_file = '2 7 4 1 5 6 8 3'
output = open('output - 1.txt', 'w')
n = int(input_file.readline())
# n = 8

temp_list = list(map(int, input_file.readline().split()))
# temp_list = list(map(int, input_file.split(' z')))
print(temp_list)


def merge_sort(array):
    if len(array) <= 1:
        return array, 0

    mid = len(array) // 2
    left, left_new = merge_sort(array[:mid])
    right, right_new = merge_sort(array[mid:])
    merge_arr, split = merge(left, right)

    return merge_arr, (left_new + right_new + split)


def merge(left, right):
    merge_arr = []
    p_1 = q_1 = inv_count = 0

    while p_1 < len(left) and q_1 < len(right):

        if left[p_1] <= right[q_1]:
            merge_arr.append(left[p_1])
            p_1 += 1

        else:
            merge_arr.append(right[q_1])
            q_1 += 1
            inv_count += len(left) - p_1
            # print(inv_count)

    merge_arr += left[p_1:]
    merge_arr += right[q_1:]

    return merge_arr, inv_count


len_of_sort, result_array = merge_sort(temp_list)
print(result_array)
output.write(str(result_array).strip('[]'))
