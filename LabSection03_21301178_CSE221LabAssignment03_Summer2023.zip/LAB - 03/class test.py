## Question find the fix point of an array (fix point means A[i] = i); constraints: you must write an algorithm which
## has the time complexity of O(log(n))

temp_list = [-2, -1, 1, 3, 4, 5, 6, 7]
# temp_list = [-6, -3, 0, 1, 2, 5, 11, 13]

def search(array, i = None, op = None):
    mid = len(array)//2
    if i is None:
        i = mid
    if len(array) == 1:
        if array[0] == i:
            print(True)
            return True
        else:
            return
    else:
        if op == '+':
            i += mid
        elif op == '-':
            i -= mid
        if array[mid] == i:
            print(True)
            # return True
        else:
            if array[mid] < i:
                search(array[mid+1:], i, '+')
            else:
                search(array[:mid], i, '-')


search(temp_list)
