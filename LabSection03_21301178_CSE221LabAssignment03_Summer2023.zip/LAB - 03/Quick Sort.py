temp_list = [3, 4, 6, 2, 1, 5, 7, 9, 8, 0]

def QuickSort(arr, pivot, r):
    if pivot < r:
        q = Partition(arr, pivot, r)
        QuickSort(arr, pivot, q)
        QuickSort(arr, q+1, r)


def Partition(arr, pivot, r):
    pivot_val = arr[pivot]
    i = pivot
    for j in range(i, r):
        if pivot_val > arr[j]:
            i += 1
            arr[j], arr[i] = arr[i], arr[j]

    arr[i], arr[pivot] = arr[pivot], arr[i]
    return i




QuickSort(temp_list, 0, len(temp_list))
print(temp_list)