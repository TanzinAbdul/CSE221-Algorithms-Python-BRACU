file_input = open('input - 2.txt', mode='r', encoding='utf-8-sig')
file_output = open('output- 2.txt', mode='w')

vertices, edges = list(map(int, file_input.readline().strip('\n').split(' ')))

graph_data = {}
shortest_distance_source_1 = {}
shortest_distance_source_2 = {}
visited_1 = []
visited_2 = []

for i in range(1, vertices+1):
    shortest_distance_source_1[i] = float('inf')
    shortest_distance_source_2[i] = float('inf')

for i in range(edges):
    source, destiny, weight = list(map(int, file_input.readline().strip('\n').split(' ')))
    if source in graph_data:
        graph_data[source].append((destiny, weight))
    else:
        graph_data[source] = [(destiny, weight)]

source_1, source_2 = list(map(int, file_input.readline().strip('\n').split(' ')))
shortest_distance_source_1[source_1] = 0
shortest_distance_source_2[source_2] = 0

def dijkstra(graph, starting_node, shortest_distance, visited):

    if starting_node in graph_data and starting_node not in visited:
        visited.append(starting_node)
        starting_node_distance = shortest_distance[starting_node]
        neighbours = graph_data[starting_node]
        min_neighbour_dist = float('inf')
        min_neighbour = None

        for edge in neighbours:
            neighbour = edge[0]
            neighbour_distance = edge[1]
            distance_from_starting = starting_node_distance + neighbour_distance
            if distance_from_starting < shortest_distance[neighbour]:
                shortest_distance[neighbour] = distance_from_starting

            if neighbour not in visited and neighbour_distance < min_neighbour_dist:
                min_neighbour_dist = neighbour_distance
                min_neighbour = neighbour

        #print(min_neighbour)

        dijkstra(graph, min_neighbour, shortest_distance, visited)
    else:
        return

dijkstra(graph_data, source_1, shortest_distance_source_1, visited_1)
for i in range(1, vertices+1):
    if i not in visited_1:
        dijkstra(graph_data, i, shortest_distance_source_1, visited_1)

dijkstra(graph_data, source_2, shortest_distance_source_2, visited_2)
for i in range(1, vertices+1):
    if i not in visited_2:
        dijkstra(graph_data, i, shortest_distance_source_2, visited_2)

best_destiny = None
time_difference = float('inf')
min_time = None

for i in range(1, vertices+1):
    if abs(shortest_distance_source_1[i] - shortest_distance_source_2[i]) < time_difference:
        time_difference = abs(shortest_distance_source_1[i] - shortest_distance_source_2[i])
        best_destiny = i
        if shortest_distance_source_1[i] > shortest_distance_source_2[i]:
            min_time = shortest_distance_source_1[i]
        else:
            min_time = shortest_distance_source_2[i]


# print(shortest_distance_source_1)
# print(shortest_distance_source_2)

if min_time is None:
    # print('Impossible')
    file_output.write('Impossible')
else:
    # print('Time', min_time)
    file_output.write('Time', str(min_time))
    # print('Node', best_destiny)
    file_output.write('Node', str(best_destiny))

