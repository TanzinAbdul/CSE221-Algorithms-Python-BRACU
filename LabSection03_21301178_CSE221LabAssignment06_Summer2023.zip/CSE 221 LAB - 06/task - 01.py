file_input = open('input 1.txt', mode='r', encoding='utf-8-sig')
file_output = open('output 1.txt', mode='w')

vertices, edges = list(map(int, file_input.readline().strip('\n').split(' ')))

graph_data = {}
shortest_distance = {}
visited = []
for i in range(1, vertices+1):
    shortest_distance[i] = float('inf')

for i in range(edges):
    source, destiny, weight = list(map(int, file_input.readline().strip('\n').split(' ')))
    if source in graph_data:
        graph_data[source].append((destiny, weight))
    else:
        graph_data[source] = [(destiny, weight)]

source = int(file_input.readline())
shortest_distance[source] = 0
# print(graph_data)

def dijkstra(graph, starting_node = None):
    global visited
    global source

    if starting_node is None:
        starting_node = source

    if starting_node in graph_data and starting_node not in visited:
        visited.append(starting_node)
        starting_node_distance = shortest_distance[starting_node]
        neighbours = graph_data[starting_node]
        min_neighbour_dist = float('inf')
        min_neighbour = None

        for edge in neighbours:
            neighbour = edge[0]
            neighbour_distance = edge[1]
            distance_from_starting = starting_node_distance + neighbour_distance
            if distance_from_starting < shortest_distance[neighbour]:
                shortest_distance[neighbour] = distance_from_starting

            if neighbour not in visited and neighbour_distance < min_neighbour_dist:
                min_neighbour_dist = neighbour_distance
                min_neighbour = neighbour


        '''for vertex in shortest_distance.keys():
            if vertex not in visited and shortest_distance[vertex] < min_neighbour_dist:
                min_neighbour_dist = shortest_distance[vertex]
                min_neighbour = vertex'''

        #print(min_neighbour)

        dijkstra(graph, min_neighbour)
    else:
        return

dijkstra(graph_data)
for i in range(1, vertices+1):
    if i not in visited:
        dijkstra(graph_data, i)

# print(visited)
for key in shortest_distance:
    if shortest_distance[key] == float('inf'):
        # print('-1', end=' ')
        file_output.write('-1 ')
    else:
        # print(shortest_distance[key], end=' ')
        file_output.write(str(shortest_distance[key])+' ')

