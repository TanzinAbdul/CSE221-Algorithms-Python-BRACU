file_input = open('input - 3.txt', mode='r', encoding='utf-8-sig')
file_output = open('output - 3.txt', mode='w')

vertices, edges = list(map(int, file_input.readline().strip('\n').split(' ')))
destiny = vertices

graph_data = {}
shortest_distance = {}
visited = []
for i in range(1, vertices+1):
    shortest_distance[i] = float('inf')

for i in range(edges):
    source, destiny, weight = list(map(int, file_input.readline().strip('\n').split(' ')))
    if source in graph_data:
        graph_data[source].append((destiny, weight))
    else:
        graph_data[source] = [(destiny, weight)]


shortest_distance[1] = 0
# print(graph_data)

def dijkstra(graph, starting_node, max_diff = float('-inf')):
    global visited
    global destiny

    if starting_node in graph_data and starting_node not in visited:
        visited.append(starting_node)
        # starting_node_distance = shortest_distance[starting_node]
        neighbours = graph_data[starting_node]
        # print(neighbours)
        min_neighbour_dist = float('inf')
        min_neighbour = None

        for edge in neighbours:
            neighbour = edge[0]
            neighbour_distance = edge[1]

            # print(neighbour, neighbour_distance, 'test')
            if neighbour not in visited and neighbour_distance < min_neighbour_dist:
                # print(neighbour, 'n', neighbour_distance)
                min_neighbour_dist = neighbour_distance
                min_neighbour = neighbour
                if neighbour_distance > max_diff:
                    # print(neighbour_distance, neighbour)
                    max_diff = neighbour_distance
            # print('xxx', neighbour, neighbour_distance)
                if neighbour == destiny:
                    # print(max_diff)
                    if max_diff < shortest_distance[destiny]:
                        shortest_distance[destiny] = max_diff


        dijkstra(graph, min_neighbour, max_diff)
    else:
        return

dijkstra(graph_data, 1)
for i in range(1, vertices+1):
    if i not in visited:
        dijkstra(graph_data, i)

# print(shortest_distance[destiny])
file_output.write(str(shortest_distance[destiny]))