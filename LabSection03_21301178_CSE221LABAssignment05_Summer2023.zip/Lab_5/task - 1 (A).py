file_input=open("input1.txt","r", encoding='utf-8-sig')
file_output=open("output1A.txt","w")
data = file_input.readlines()
edges= data[1:]

source_to_destination={}
for edge in edges:
  edge = edge.split()
  if int(edge[0]) not in source_to_destination.keys():
    source_to_destination[int(edge[0])]=[]
  if int(edge[1]) not in source_to_destination.keys():
    source_to_destination[int(edge[1])]=[]
  source_to_destination[int(edge[0])].append(int(edge[1]))


detect={}
parent={}
output= False

for edge in source_to_destination.keys():
  detect[edge]= "white"
  parent[edge]= "None"
def cycle_detect(u):
  global output
  detect[u]= "grey"
  for k in source_to_destination[u]:
    if detect[k] == "white":
        parent[k]=u
        cycle_detect(k)
    if detect[k]== "grey":
      output= "yes"
  detect[u]= "B"


def DFS(graph, visited, node, stack):
  visited.add(node)
  for neighbours in graph[node]:
    if neighbours not in visited:
      DFS(graph, visited, neighbours, stack)
  stack.append(node)


def TopSort(graph):
  for node in graph:
    cycle_detect(node)
    break
  if output== "yes":
    return "IMPOSSIBLE"
  visited = set()
  stack = []
  for node in graph:
    if node not in visited:
      DFS(graph, visited, node, stack)

  return (str(stack[::-1])[1:-1]).replace(","," ")


for vertex in source_to_destination:
  cycle_detect(vertex)

if output== "yes":
  file_output.write("Impossible")
  #print("Impossible")
else:
  top_sort=TopSort(source_to_destination)
  file_output.write(top_sort)
  #print(top_sort)