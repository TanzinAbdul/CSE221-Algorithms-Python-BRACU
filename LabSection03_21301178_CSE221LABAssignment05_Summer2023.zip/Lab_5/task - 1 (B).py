from collections import deque

file_input=open("input1.txt","r", encoding='utf-8-sig')
file_output=open("output1B.txt","w")

data=file_input.readlines()
edges= data[1:]
graph={}

indegree_dict={}

for edge in edges:
  edge=list(map(int, edge.split()))

  if edge[0] not in graph.keys():
    graph[edge[0]]=[]
    indegree_dict[edge[0]]=0

  if edge[1] not in graph.keys():
    graph[edge[1]]=[]
    indegree_dict[edge[1]]=0
  graph[edge[0]].append(edge[1])
  indegree_dict[edge[1]]= indegree_dict[edge[1]] + 1

color_assign={}
parent={}
output= False

for edge in graph.keys():
  color_assign[edge]= "w"
  parent[edge]= "None"

def cycle_detection(u):
  global output
  color_assign[u]= "g"
  for i in graph[u]:
    if color_assign[i] == "w":
        parent[i]=u
        cycle_detection(i)
    if color_assign[i]== "g":
      result="yes"
  color_assign[u]= "B"
queue=deque([])

def TopSort_BFS():
    global queue
    result=[]
    for node in indegree_dict:
       # print(node)
        if indegree_dict[node]==0:
            queue.append(node)
            indegree_dict[node]-=1

    while queue:
        new_temp =queue.popleft()
        result.append(new_temp)
        for node in graph[new_temp]:
            indegree_dict[node]-=1
        for node in indegree_dict:
            if indegree_dict[node]==0:
                queue.append(node)
                indegree_dict[node]-=1
    return result
for node in graph:
  cycle_detection(node)
  if output is "yes":
    file_output.write("Impossible")
    break
if output is False:
  output=TopSort_BFS()
  output= str(output)[1:-1].replace(",", " ")
  file_output.write(output)
