##########################  task 3 ##############
file_input=open("input3.txt","r", encoding='utf-8-sig')
file_output=open("output3.txt","w")

data=file_input.readlines()
total_nodes=int(data[0][0])
edges= data[1:]
graph={}
start_time_graph={}
end_time_graph={}
graph_reverse={}
time=1
list=[]

visited = set()
#start_time_graph_reverse={}
################################ initialization of dictionary #################
for i in range(1, total_nodes + 1):
  graph[i]=[]
  graph_reverse[i]=[]
  start_time_graph[i]=None
  end_time_graph[i]=None
  #start_time_graph_reverse[i]=[]

for edge in edges:
  edge = edge.split()
  graph[int(edge[0])].append(int(edge[1]))
  graph_reverse[int(edge[1])].append(int(edge[0]))

def DFS(graph_data, source, visited):
  global time
  visited.add(source)
  start_time_graph[source]=time
  time+=1
  for adjacent in graph_data[source]:
    if adjacent not in visited:
      DFS(graph_data, adjacent, visited)
  end_time_graph[source]=time
  time+=1
  
def SCC(graph_data, node, visited):
  global time
  global list
  visited.add(node)
  start_time_graph[node]=time
  time+=1
  for neighbours in graph_data[node]:
    if neighbours not in visited:
      SCC(graph_data, neighbours, visited)
  end_time_graph[node]=time
  list.append(node)
  time+=1

for node in graph:
  if node not in visited:
    DFS(graph, node, visited)

end_time_sorted_graph= dict(sorted(end_time_graph.items(), key=lambda item: item[1], reverse=True))
visited=set()
time=1
ssc_lst=[]
for node in end_time_sorted_graph:
  if node not in visited:
    SCC(graph_reverse, node, visited)
    ssc_lst.append(list)
    list=[]
for i in ssc_lst:
  file_output.write((str(i)[1:-1]).replace(","," "))
  file_output.write("\n")