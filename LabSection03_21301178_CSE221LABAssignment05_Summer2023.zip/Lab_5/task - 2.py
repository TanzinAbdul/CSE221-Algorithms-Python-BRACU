import heapq
file_input=open("input2.txt","r", encoding='utf-8-sig')
file_output=open("output2.txt","w")

data=file_input.readlines()
edges= data[1:]
#print(connections)
graph={}
in_degree={}

for edge in edges:
  edge=list(map(int, edge.split()))

  if edge[0] not in graph.keys():
    graph[edge[0]]=[]
    in_degree[edge[0]]=0

  if edge[1] not in graph.keys():
    graph[edge[1]]=[]
    in_degree[edge[1]]=0
  graph[edge[0]].append(edge[1])
  in_degree[edge[1]]= in_degree[edge[1]] + 1


color_assign={}
parent={}

output= False

for i in graph.keys():
  color_assign[i]= "w"
  parent[i]="None"

def cycle_detect(u):
  global output
  color_assign[u]= "g"
  for i in graph[u]:
    if color_assign[i] == "w":
        parent[i]=u
        cycle_detect(i)
    if color_assign[i]== "g":
      result="yes"
  color_assign[u]= "B"


queue=[]
heapq.heapify(queue)

def TopSort_BFS():
    global queue
    result=[]
    for nod in in_degree:
        if in_degree[nod]==0:
            heapq.heappush(queue,nod)
            in_degree[nod]-=1

    while queue:
        temp=heapq.heappop(queue)
        result.append(temp)
        for nod in graph[temp]:
            in_degree[nod]-=1
        for nod in in_degree:
            if in_degree[nod]==0:
                heapq.heappush(queue,nod)
                in_degree[nod]-=1
    return result

for node in graph:
  cycle_detect(node)
  if output== "yes":
    file_output.write("Impossible")
    break

if output== "No":
  output=TopSort_BFS()
  output= str(output)[1:-1].replace(",", " ")
  file_output.write(output)