file_input = open('input1a.txt', mode='r', encoding='utf-8-sig')
file_output = open('output1a.txt', mode='w')
lines = int(file_input.readline())

def number_checker(num):
    if num % 2 == 0:
        return f'{num} is an even number.\n'
    else:
        return f'{num} is an odd number.\n'

for i in range(lines):
    num = int(file_input.readline())
    file_output.write(number_checker(num))

