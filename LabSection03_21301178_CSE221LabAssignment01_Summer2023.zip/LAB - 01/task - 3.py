file_input = open('input3.txt', mode='r', encoding='utf-8-sig')
file_output = open('output3.txt', mode='w')
num_of_elements = int(file_input.readline())

id_mark_dict = {}
student_ids = list(map(int, file_input.readline().strip('\n').split(' ')))
student_marks = list(map(int, file_input.readline().strip('\n').split(' ')))

for i in range(len(student_marks) - 1):
    sort_checker = True
    for j in range(len(student_marks) - i - 1):
        if student_marks[j] < student_marks[j + 1]:
            sort_checker = False
            student_marks[j], student_marks[j + 1] = student_marks[j + 1], student_marks[j]
            student_ids[j], student_ids[j+1] = student_ids[j+1], student_ids[j]
    if sort_checker is True:
        break


for i in range(num_of_elements):
    file_output.write(f'ID: {student_ids[i]} Mark: {student_marks[i]}\n')
