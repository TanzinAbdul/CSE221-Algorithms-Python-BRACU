file_input = open('input4.txt', mode='r', encoding='utf-8-sig')
file_output = open('output4.txt', mode='w')
#num_of_lines = int(file_input.readline())
departure = file_input.readlines()[1:]
time = list(map(lambda t: (t.split()[0], t.split()[-1]), departure))


def timecmp(ex1, ex2):
    hour1, min_1 = map(int, ex1.split(":"))
    hour2, min_2 = map(int, ex2.split(":"))

    if hour1 < hour2:
        return True

    elif hour1 == hour2:
        return min_1 < min_2

    else:
        return False


for i in range(len(departure) - 1):
    c = 0

    for j in range(len(departure) - i - 1):

        if time[j][0] > time[j + 1][0] or (time[j][0] == time[j + 1][0] and timecmp(time[j][1], time[j + 1][1])):
            temp2 = departure[j]

            departure[j] = departure[j + 1]
            departure[j + 1] = temp2

            temp = time[j]

            time[j] = time[j + 1]
            time[j + 1] = temp

            c += 1

    if c == 0:
        break

for trainSchedule in departure:
    file_output.write(trainSchedule)

file_output.close()



