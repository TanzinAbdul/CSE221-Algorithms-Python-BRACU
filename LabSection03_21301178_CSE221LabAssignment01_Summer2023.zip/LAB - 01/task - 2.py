file_input = open('input2.txt', mode='r', encoding='utf-8-sig')
file_output = open('output2.txt', mode='w')
length_arr = int(file_input.readline())
array = list(map(int, file_input.readline().strip('\n').split(' ')))

def bubbleSort(arr):
    for i in range(len(arr)-1):
        sort_checker = True
        for j in range(len(arr)-i-1):
            if arr[j] > arr[j+1]:
                sort_checker = False
                arr[j], arr[j+1] = arr[j+1], arr[j]
        if sort_checker is True:
            break

'''In the Bubble Sort Algorith there is nested loops, in the inner loop it checks
the whole array in the first iteration, where it can be actually checked if the array
is sorted or not since bubble sort compare every element with it's immediate value, we can 
go by ascending or descending to determine whether the array is sorted.'''

bubbleSort(array)
file_output.write(str(array))