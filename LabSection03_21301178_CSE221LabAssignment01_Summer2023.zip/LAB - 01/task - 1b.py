file_input = open('input1b.txt', mode='r', encoding='utf-8-sig')
file_output = open('output1b.txt', mode='w')
lines = int(file_input.readline())

def calculate(data):
    num_1, operator, num_2 = data.split(' ')
    num_1, num_2 = int(num_1), int(num_2)
    if operator == '+':
        return f'The result of {data} is {num_1 + num_2}\n'
    elif operator == "*":
        return f'The result of {data} is {num_1 * num_2}\n'
    elif operator == '-':
        return f'The result of {data} is {num_1 - num_2}\n'
    elif operator == '/':
        return f'The result of {data} is {num_1 / num_2}\n'


for i in range(lines):
    data = file_input.readline()
    file_output.write(calculate(data.strip('\n')[10:]))