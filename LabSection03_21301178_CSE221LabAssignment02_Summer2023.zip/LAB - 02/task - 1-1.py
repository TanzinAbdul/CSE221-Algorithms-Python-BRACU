file_input = open('input 1-1.txt', mode='r', encoding='utf-8-sig')
file_output = open('output 1-2.txt', mode='w')

first_line = file_input.readline().split(' ')
num_list = file_input.readline().split(' ')
limit = int(first_line[0])
result = int(first_line[1])
temp_dict = {}

for num in num_list:
    if temp_dict.get(num) is None:
        temp_dict[num] = 1
    else:
        temp_dict[num] += 1


ind = 0
for num in num_list:
    sub = int(result) - int(num)
    if temp_dict.get(str(sub)) == 1 and sub != int(num):
        ind_1 = num_list.index(str(num))+1
        ind_2 = num_list.index(str(sub))+1
        output = f'{ind_1} {ind_2}'

        break

    elif temp_dict.get(str(sub)) is not None and temp_dict.get(str(sub)) > 1:
        temp_list = num_list.copy()
        temp_list.pop(ind)
        if ind < temp_list.index(str(sub)):
            ind_1 = ind+1
            ind_2 = temp_list.index(str(sub))+2
            output = f'{ind_1} {ind_2}'
        else:
            ind_1 = ind + 1
            ind_2 = temp_list.index(str(sub)) + 1
            output = f"{ind_1} {ind_2}"
        break

    else:
        output = "IMPOSSIBLE"

    ind += 1


file_output.write(output)