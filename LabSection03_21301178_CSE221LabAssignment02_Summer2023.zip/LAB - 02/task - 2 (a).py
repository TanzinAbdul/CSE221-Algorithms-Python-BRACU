file_input = open('input - 2.txt', mode='r', encoding='utf-8-sig')

n = int(file_input.readline())
alice = list(map(int, file_input.readline().strip('\n').split(' ')))
m = int(file_input.readline())
bob = list(map(int, file_input.readline().strip('\n').split(' ')))

combined_list  = alice + bob
sorted_list = sorted(combined_list)
print(sorted_list)

