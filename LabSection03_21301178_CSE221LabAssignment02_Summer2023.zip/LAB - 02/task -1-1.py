file_input = open('input 1-1.txt', mode='r', encoding='utf-8-sig')
file_output = open('output 1-1.txt', mode='w')

first_line = file_input.readline().split(' ')
lis1 = file_input.readline().split(' ')
limit = int(first_line[0])
result = int(first_line[1])
output = "IMPOSSIBLE"

for i in lis1:
    sub = result - int(i)
    temp = lis1.copy()
    temp.remove(i)
    if str(sub) in temp:
        output = str(lis1.index(str(i))+1)
        if lis1.index(str(i)) > temp.index(str(sub)):
            output += str(temp.index(str(sub))+1)
        else:
            output += " " + str(temp.index(str(sub))+2)
        break

file_output.write(output)
