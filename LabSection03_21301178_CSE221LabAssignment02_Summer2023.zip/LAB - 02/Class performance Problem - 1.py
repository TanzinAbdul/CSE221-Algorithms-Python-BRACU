
array_1 = [1, 5, 8, 9]
array_2 = [2, 4, 7, 11]
a = 5

def sorted_selected(A, B, k):
    kth_small = None
    i_1 = 0
    i_2 = 0
    for i in range(k):
        if A[i_1] < B[i_2]:
            i_1 += 1
            kth_small = A[i_1-1]
        else:
            i_2 += 1
            kth_small = B[i_2-1]
    print(kth_small)






sorted_selected(array_1, array_2, a)