def merge(arr_1, arr_2):
    size = len(arr_1) + len(arr_2)
    output_arr = [0] * size
    i, j, k = 0, 0, 0
    while j < len(arr_1) and k < len(arr_2):
        if arr_1[j] < arr_2[k]:
            output_arr[i] = arr_1[j]
            j += 1
        else:
            output_arr[i] = arr_2[k]
            k += 1
        i += 1

    if j == 0 or j < len(arr_1):
        for x in range(j, len(arr_1)):
            output_arr[i] = arr_1[x]
            i += 1
    elif k == 0 or k < len(arr_2):
        for y in range(k, len(arr_2)):
            output_arr[i] = arr_2[y]
            i += 1
    return output_arr


def mergeSort(array):
    if len(array) <= 1:
        return array
    else:
        mid = len(array) // 2
        a1 = mergeSort(array[:mid])
        a2 = mergeSort(array[mid:])
        return merge(a1, a2)


file_input = open('input 3.txt', mode='r')
file_output = open('output 3.txt', mode='w')
size = file_input.readline()
temp_array = list(map(int, file_input.readline().split(' ')))
mergeSort(temp_array)

for x in temp_array:
    file_output.write(str(x)+' ')
