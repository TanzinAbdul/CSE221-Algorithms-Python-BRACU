file_input = open('input - 2.txt', mode='r', encoding='utf-8-sig')

n = int(file_input.readline())
alice = list(map(int, file_input.readline().strip('\n').split(' ')))
m = int(file_input.readline())
bob = list(map(int, file_input.readline().strip('\n').split(' ')))

combined_range = m + n
new_array = [0]*combined_range
a = 0
b = 0
for i in range(combined_range):
    if a < n and b < m:
        if alice[a] < bob[b]:
            new_array[i] = alice[a]
            a += 1
        else:
            new_array[i] = bob[b]
            b += 1


if a < n-1:
    for j in range(i-1, combined_range):
        new_array[j] = alice[a]
        a += 1
elif b < m-1:
    for j in range(i-1, combined_range):
        new_array[j] = bob[b]
        b += 1

print(new_array)



