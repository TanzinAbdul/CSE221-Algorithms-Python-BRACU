def find_max(arr_1, arr_2):
    if arr_1[0] > arr_2[0]:
        return arr_1
    else:
        return arr_2


def mergeSort(array):
    if len(array) <= 1:
        return array
    else:
        mid = len(array) // 2
        a1 = mergeSort(array[:mid])
        a2 = mergeSort(array[mid:])
        return find_max(a1, a2)


file_input = open('input 4.txt', mode='r')
file_output = open('output 4.txt', mode='w')
size = file_input.readline()
temp_array = list(map(int, file_input.readline().strip('\n').split(' ')))
print(temp_array)
print(mergeSort(temp_array))

