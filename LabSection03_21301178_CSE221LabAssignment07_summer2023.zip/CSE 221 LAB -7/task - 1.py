file_input = open('input 1.txt', mode='r', encoding='utf-8-sig')
file_output = open('output 1.txt', mode='w')

n = int(file_input.readline())
# print(n)

temp_list = [' ']*n

for i in range(n):
    # print(i)
    a, b = list(map(int, file_input.readline().strip('\n').split(' ')))
    # print(a, b)
    temp_list[i] = [a, b]

# print(temp_list)
# temp_list.sort()
for i in range(n):
    for j in range(n):
        if temp_list[i][1] < temp_list[j][1]:
            # print(temp_list[j])
            temp_list[i], temp_list[j] = temp_list[j], temp_list[i]
# print(temp_list)


s, e = 0, 1
print(temp_list[s])
file_output.write(str(temp_list[s]).strip('[]').replace(',', '')+'\n')
while (s < n-1) and (e < n-1):
    # print(temp_list[s], temp_list[e])
    if (temp_list[s][1] == temp_list[e][0]) or (temp_list[s][1] < temp_list[e][0]):
        # print(temp_list[s])
        print(temp_list[e])
        file_output.write(str(temp_list[e]).strip('[]').replace(',', '')+'\n')
        s = e
        e += 1
    else:
        e += 1

if (temp_list[s][1] == temp_list[e][0]) or (temp_list[s][1] < temp_list[e][0]):
    print(temp_list[e])
    file_output.write(str(temp_list[e]).strip('[]').replace(',', '')+'\n')



