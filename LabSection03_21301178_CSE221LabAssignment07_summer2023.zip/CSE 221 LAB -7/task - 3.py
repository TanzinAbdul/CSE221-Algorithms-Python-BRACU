file_input = open('input 3.txt', mode='r', encoding='utf-8-sig')
file_output = open('output_3.txt', mode='w')

people, connections = list(map(int, file_input.readline().strip('\n').split(' ')))
individual_people = [{x} for x in range(1, people+1)]

person_a, person_b = list(map(int, file_input.readline().strip('\n').split(' ')))

friend_circle = [{person_a} | {person_b}]
# print(len(friend_circle[0]))
file_output.write(str(len(friend_circle[0]))+'\n')
# print(friend_circle)

for i in range(connections-1):
    person_a, person_b = list(map(int, file_input.readline().strip('\n').split(' ')))
    temp_circle = {person_a} | {person_b}
    # print(temp_circle)
    for circle in friend_circle:

        if person_a in circle and len(friend_circle) > 1:
            flag = False
            for friends in friend_circle:
                if person_b in friends and friends != circle:
                    new_friends = circle | friends
                    # print(new_friends)
                    friend_circle.append(new_friends)
                    friend_circle.remove(circle)
                    friend_circle.remove(friends)
                    # print(len(new_friends))
                    file_output.write(str(len(new_friends))+'\n')
                    flag = True
                    break
            if flag:
                break

        elif person_b in circle and len(friend_circle) > 1:
            flag = False
            for friends in friend_circle:
                if person_a in friends and friends != circle:
                    # print(True)
                    new_friends = circle | friends
                    # print('new friends', new_friends)
                    friend_circle.remove(circle)
                    friend_circle.remove(friends)
                    friend_circle.append(new_friends)
                    # print(len(new_friends))
                    file_output.write(str(len(new_friends))+'\n')
                    flag = True
                    break
            if flag:
                break

        if circle.intersection(temp_circle) != set():
            new_circle = circle | temp_circle
            # print(len(new_circle))
            file_output.write(str(len(new_circle))+'\n')
            friend_circle.append(new_circle)
            friend_circle.remove(circle)
            no_prev_circle = False
            break

        else:
            no_prev_circle = True

        if no_prev_circle:
            friend_circle.append(temp_circle)

    # print(friend_circle)



