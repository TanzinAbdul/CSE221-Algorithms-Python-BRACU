file_input = open('input 2.txt', mode='r', encoding='utf-8-sig')
file_output = open('output 2.txt', mode='w')

n, m = list(map(int, file_input.readline().strip('\n').split(' ')))
# print(n)

temp_list = [' ']*n

for i in range(n):
    # print(i)
    a, b = list(map(int, file_input.readline().strip('\n').split(' ')))
    # print(a, b)
    temp_list[i] = [a, b]

# print(temp_list)
# temp_list.sort()


for i in range(n):
    for j in range(n):
        if temp_list[i][1] < temp_list[j][1]:
            # print(temp_list[j])
            temp_list[i], temp_list[j] = temp_list[j], temp_list[i]
# print(temp_list)


def find_task(giv_list):

    c = 0
    s, e = 0, 1
    if giv_list[s] == 0:
        s += 1
        if s == e:
            e += 1
    # print(giv_list[s])
    c += 1

    while (s < n-1) and (e < n-1):
        # print(temp_list[s], temp_list[e])
        if (giv_list[s] != 0) and (giv_list[e] != 0):
            if giv_list[s][1] == giv_list[e][0]:
                # print(temp_list[s])
                giv_list[s] = 0
                # print(giv_list[e])
                c += 1
                s = e
                e += 1
            elif giv_list[s][1] < giv_list[e][0]:
                giv_list[s] = 0
                # print(giv_list[e])
                c += 1
                s = e
                e += 1
            else:
                e += 1
        else:
            if giv_list[s] == 0:
                s += 1
                if s == e:
                    e += 1
            elif giv_list[e] == 0:
                e += 1

    if giv_list[e] != 0:
        if (giv_list[s][1] == giv_list[e][0]) or (giv_list[s][1] < giv_list[e][0]):
            # print(giv_list[e])
            c += 1

    giv_list[e] = 0

    return c


result = 0

for i in range(m):
    count = find_task(temp_list)
    result += count

print(result)
file_output.write(str(result))
