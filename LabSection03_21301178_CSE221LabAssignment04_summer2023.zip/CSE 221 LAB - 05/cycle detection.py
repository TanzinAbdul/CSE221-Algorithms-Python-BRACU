file_input = open('cycle_detection.txt', mode='r', encoding='utf-8-sig')
# file_output = open('output_3.txt', mode='w')
vertices, edges = file_input.readline().split(' ')
source_to_destination = {}

for i in range(int(edges)):
    data = list(map(int, file_input.readline().split(' ')))
    if data[0] not in source_to_destination:
        source_to_destination[data[0]] = [data[1]]
    else:
        source_to_destination[data[0]].append(data[1])

print(source_to_destination)
visited = []
output = ''


def cycle_detection(graph, vertex=None):
    global output
    # print(visited)
    if vertex is None:
        vertex = list(graph.keys())[0]
        visited.append(vertex)
        print(vertex)

    if vertex in graph:
        if graph[vertex][0] not in visited:
            print(graph[vertex][0])
            visited.append(graph[vertex][0])
            cycle_detection(graph, graph[vertex][0])
        else:
            print('x')
            output = 'cycle found'
    visited.remove(vertex)
    if graph.get(vertex) is not None:
        if len(graph[vertex]) > 1:
            for ind in range(1, len(graph[vertex])):
                neighbour = graph[vertex][ind]
                if neighbour not in visited:
                    print(neighbour)
                    visited.append(neighbour)
                    cycle_detection(graph, neighbour)
                else:
                    print('y')
                    output = 'cycle found'

    if output == 'cycle found':
        return output
    else:
        return 'no cycle found'


print(cycle_detection(source_to_destination))

