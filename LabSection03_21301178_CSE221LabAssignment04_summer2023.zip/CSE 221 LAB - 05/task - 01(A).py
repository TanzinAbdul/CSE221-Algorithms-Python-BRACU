file_input = open('input_1(A).txt', mode='r', encoding='utf-8-sig')
file_output = open('output_1(A).txt', mode='w')
vertices, edges = file_input.readline().split(' ')
source_to_destination = {}

for i in range(int(edges)):
    data = list(map(int, file_input.readline().split(' ')))
    if data[0] not in source_to_destination:
        source_to_destination[data[0]] = [(data[1], data[2])]
    else:
        source_to_destination[data[0]].append((data[1], data[2]))

print(source_to_destination)
result_matrix = ''

for i in range(int(vertices)+1):

    matrix_line = ('0 ' * len(vertices)) * (int(vertices) + 1)
    if i in source_to_destination:
        for destiny in source_to_destination[i]:
            matrix_line = matrix_line[0: ((destiny[0]+1) * (len(vertices)+1)-2)] + str(destiny[1]) + matrix_line[((destiny[0]+1) * (len(vertices)+1)-1):]
        result_matrix += matrix_line + '\n'
    else:
        result_matrix += matrix_line + '\n'

print(result_matrix)

file_output.write(result_matrix)