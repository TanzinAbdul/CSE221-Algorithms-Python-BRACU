file_input = open('input_3.txt', mode='r', encoding='utf-8-sig')
file_output = open('output_3.txt', mode='w')
vertices, edges = file_input.readline().split(' ')
source_to_destination = {}

for i in range(int(edges)):
    data = list(map(int, file_input.readline().split(' ')))
    if data[0] not in source_to_destination:
        source_to_destination[data[0]] = [data[1]]
    else:
        source_to_destination[data[0]].append(data[1])

print(source_to_destination)
visited = []
# print(len(source_to_destination))


def DFS(graph, vertex=None):
    # print(visited)
    if vertex is None:
        vertex = list(graph.keys())[0]
        visited.append(vertex)
        print(vertex)

    if graph.get(vertex) is not None:
        if graph[vertex][0] not in visited:
            print(graph[vertex][0])
            visited.append(graph[vertex][0])
            DFS(graph, graph[vertex][0])

    if graph.get(vertex) is not None:
        if len(graph[vertex]) > 1:
            for neighbour in graph[vertex]:
                if neighbour not in visited:
                    print(neighbour)
                    visited.append(neighbour)
                    DFS(graph, neighbour)

    return


DFS(source_to_destination)

