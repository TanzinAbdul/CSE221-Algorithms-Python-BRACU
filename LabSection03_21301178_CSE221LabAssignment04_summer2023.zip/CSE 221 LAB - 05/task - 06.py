import numpy as np


def top(diamond, block_1, block_2, Q):
    try:
        block_1 = (block_1 - 1)
        if [block_1, block_2] not in travel:
            if block_1 >= 0 and block_2 >= 0:
                if diamond[block_1][block_2] != "#":
                    travel.append([block_1, block_2])
                    Q.append([block_1, block_2])
    except:
        pass


def bottom(diamond, temp_1, temp_2, Q):
    try:
        temp_1 += 1

        if [temp_1, temp_2] not in travel:
            if temp_1 >= 0 and temp_2 >= 0:
                if diamond[temp_1][temp_2] != "#":
                    travel.append([temp_1, temp_2])
                    Q.append([temp_1, temp_2])

    except:
        pass


def left(diamonds, var_1, var_2, Q):
    try:
        var_2 = (var_2 - 1)

        if [var_1, var_2] not in travel:
            if var_1 >= 0 and var_2 >= 0:
                if diamonds[var_1][var_2] != "#":
                    travel.append([var_1, var_2])
                    Q.append([var_1, var_2])

    except:
        pass


def right(diamonds, x, y, Q):
    try:
        y = (y + 1)

        if [x, y] not in travel:
            if x >= 0 and y >= 0:
                if diamonds[x][y] != "#":
                    travel.append([x, y])
                    Q.append([x, y])

    except:
        pass


def path_check_dots(diamonds):
    for i in range(len(diamonds)):
        if "." in diamonds[i]:
            for j in range(len(diamonds[i])):
                if diamonds[i][j] == ".":
                    return [i, j]
    i = (i + 1)




input_file = open("input 6.txt", "r", encoding='utf-8-sig')
output = open("output_6.txt", "w")
line = input_file.readline().split()
nodes, egdes = int(line[0]), int(line[1])
diamonds = []

for start in range(nodes):
    read = input_file.readline().strip()
    temp = [i for i in read]
    diamonds.append(temp)
diamonds = np.array(diamonds)
travel = []
Diamond_count = []

start = 0

while (start == 0):
    Q = [path_check_dots(diamonds)]
    c = 0
    while True:
        out = Q.pop(0)
        try:
            top(diamonds, out[0], out[1], Q)
            bottom(diamonds, out[0], out[1], Q)
            left(diamonds, out[0], out[1], Q)
            right(diamonds, out[0], out[1], Q)
            if diamonds[out[0]][out[1]] == "D":
                c = (c + 1)
            diamonds[out[0]][out[1]] = 1
        except:
            start = (start + 1)
        if Q == []:
            break
    Diamond_count.append(c)
    result = max(Diamond_count)


output.write(str(result))
