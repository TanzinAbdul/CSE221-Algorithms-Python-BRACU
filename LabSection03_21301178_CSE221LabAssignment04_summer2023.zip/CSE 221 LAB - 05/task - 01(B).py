file_input = open('input_1(B).txt', mode='r', encoding='utf-8-sig')
file_output = open('output_1(B).txt', mode='w')
vertices, edges = file_input.readline().split(' ')
adjacency_list = [' ']*int(vertices)

for i in range(int(edges)):
    source, destination, weight = list(map(int, file_input.readline().split(' ')))
    if adjacency_list[source] == ' ':
        adjacency_list[source] = []
        adjacency_list[source].append((destination, weight))
    else:
        adjacency_list[source].append((destination, weight))

for i in range(len(adjacency_list)):
    output = str(i) + ' : ' + str(adjacency_list[i]).strip("[]")
    print(output)
    file_output.write(output+'\n')

