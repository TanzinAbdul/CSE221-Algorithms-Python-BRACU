file_input = open("input_5.txt", "r")
file_output = open("output_5.txt", "w")
vertices, edges, destination = file_input.readline().split()
vertices, edges, destination = int(vertices), int(edges), int(destination)
adjacent_list = [[]] * vertices
list_1 = []
counter = 0

while counter < edges:
    list_2 = []
    list_3 = []
    node_1, node_2 = file_input.readline().split()
    node_1, node_2 = int(node_1), int(node_2)
    if node_1 in list_1:
        adjacent_list[node_1 - 1].append(node_2)
    else:
        list_1.append(node_1)
        list_2.append(node_2)
        adjacent_list[node_1 - 1] = list_2
        counter += 1
    if node_2 in list_1:
        adjacent_list[node_2 - 1].append(node_1)
        counter += 1
    else:
        list_1.append(node_2)
        list_3.append(node_1)
        adjacent_list[node_2 - 1] = list_3
    counter += 1

counter_2 = 0
time = {1: 0}
parent = {1: 0}
visited = [1]
queue = [1]
while queue:
    deQ = queue.pop(0)
    for i in adjacent_list[deQ - 1]:
        if i not in visited:
            visited.append(i)
            queue.append(i)
            parent[i] = deQ

visited_2 = [1]
queue = [1]
while queue:
    deQ = queue.pop(0)
    counter_2 += 1
    for i in adjacent_list[deQ - 1]:
        if i not in visited_2:
            visited_2.append(i)
            queue.append(i)
            counter_2 = time[parent[i]] + 1
            time[i] = counter_2

file_output.writelines(f"Time: {time[destination]}\nShortest Path: ")
path = []
i = destination
while i != 0:
    path.append(i)
    i = parent[i]
for j in range(-1,-(len(path)+1),-1):
  file_output.writelines(f"{path[j]} ")

