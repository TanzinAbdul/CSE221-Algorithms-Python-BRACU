def dfs(visited, graph, i):
    if i not in visited:
        file_output.write(f"{str(i)} ")
        visited.add(i)
        # print(f"visited: {visited}")
        for neighbour in graph[i]:
            if neighbour not in visited:
                dfs(visited, graph, neighbour)


import collections

visited = set()
ans = ""
file_input = open('input_3.txt', mode='r', encoding='utf-8-sig')
file_output = open('output_3.txt', mode='w')

n, m = file_input.readline().split()
n, m = int(n), int(m)
adj_list = {i: [] for i in range(1, n + 1)}

for i in range(m):
    n1, n2 = file_input.readline().split()
    n1, n2 = int(n1), int(n2)
    adj_list[n1].append(n2)
    adj_list[n2].append(n1)
dfs(visited, adj_list, 1)
