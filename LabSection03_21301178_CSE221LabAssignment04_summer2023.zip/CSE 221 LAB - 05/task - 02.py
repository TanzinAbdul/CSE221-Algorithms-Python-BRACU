file_input = open('input_2.txt', mode='r', encoding='utf-8-sig')
file_output = open('output_2.txt', mode='w')
vertices, edges = file_input.readline().split(' ')
# print(vertices)
result = []
source_to_destination = {}

for i in range(int(edges)):
    data = list(map(int, file_input.readline().split(' ')))
    if data[0] not in source_to_destination:
        source_to_destination[data[0]] = [data[1]]
    else:
        source_to_destination[data[0]].append(data[1])

print(source_to_destination)


def Enqueue(elem, arr, size):
    size = size % len(arr)
    # print('Enqueue', elem)
    arr[size] = elem
    # print(arr)


def Dequeue(arr, st):
    temp = arr[st]
    # print('Dequeue', temp)
    result.append(temp)
    arr[st] = 0


def BFS(dict_graph, start=0, size=0):
    queue = [0] * int(vertices)
    # print(vertices)
    # print(queue)
    vertex = list(dict_graph.keys())[0]
    # print(vertex)
    Enqueue(vertex, queue, size)
    size += 1
    for k in range(int(vertices)):
        elem = queue[start]
        Dequeue(queue, start)
        start += 1
        if elem in dict_graph:
            for vert in dict_graph[elem]:
                if vert not in queue and vert not in result:
                    Enqueue(vert, queue, size)
                    size += 1

    end = size - 1 % len(queue)
    if start != end+1:
        for j in range(start, end + 1):
            Dequeue(queue, j)

    # print(queue)


BFS(source_to_destination)

print(result)
for elem in result:
    file_output.write(str(elem)+'  ')
