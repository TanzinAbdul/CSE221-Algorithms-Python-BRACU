def cycle_detection(k, colour, parent_node):
    colour[k] = "Gray"
    for i in source_to_destination[k]:
        if colour[i] == "White":
            cycle = cycle_detection(i, colour, parent_node)
            if cycle == "Yes":
                return "Yes"
        elif colour[i] == "Gray":
            return "Yes"
    colour[k] = "Black"
    return "No"


file_input = open("input_4.txt", 'r')
file_output = open("output_4.txt", 'w')
vertices, edges = file_input.readline().split()
vertices, edges = int(vertices), int(edges)
source_to_destination = {}
for i in range(1, vertices+1):
    source_to_destination[i] = []

color, parent_vertece = {}, {}
for i in range(edges):
    source, destiny = file_input.readline().split()
    source, destiny = int(source), int(destiny)
    source_to_destination[source].append(destiny)
for j in source_to_destination.keys():
    color[j] = "White"
    parent_vertece[j] = None
cycle_found = "No"
for k in source_to_destination.keys():
    if color[k] == "White":
        cycle_found = cycle_detection(k, color, parent_vertece)
        if cycle_found == "Yes":
            break

file_output.writelines(f"{cycle_found}")

