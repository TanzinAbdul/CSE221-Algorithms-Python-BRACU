data = open('input 6.txt', mode='r', encoding='utf-8-sig')
row, column = data.readline().split(' ')
row = int(row)
maze = data.read()
element_list = []
column = int(column)
for elem in maze:
    if elem != '\n':
        element_list.append(elem)


class Node:

    def __init__(self, element, left=-1, right=-1, top=-1, bottom=-1):

        self.element = element
        self.left = left
        self.right = right
        self.top = top
        self.bottom = bottom


object_list = []

# creating Nodes
for elem in element_list:
    node = Node(elem)
    object_list.append(node)


def connect_nodes(element):
    i = 0
    if element_list[i] == '#':
        return
    while i < len(element_list):
        if -1 < i + 1 < len(element_list) and element_list[i+1] != '#':
            object_list[i].right = object_list[i+1]
        if -1 < i - 1 < len(element_list) and element_list[i-1] != '#':
            object_list[i].left = object_list[i-1]
        if -1 < i + column < len(element_list) and element_list[i+column] != '#':
            object_list[i].bottom = object_list[i+column]
        if -1 < i - column < len(element_list) and element_list[i-column] != '#':
            object_list[i].top = object_list[i-column]
        i += 1


for object in object_list:
    connect_nodes(object)

print(len(object_list))

max_diamond = 0


def count_max_diamond(object, source=None, diamond_count=0):
    global max_diamond
    print(object.element)
    if source is None:
        source = object

    if object.right != -1 and object.right != source:
        print('Right')
        if object.element == 'D':
            diamond_count += 1
        count_max_diamond(object.right, source, diamond_count)

    if object.bottom != -1 and object.bottom != source:
        print('bottom')
        if object.element == 'D':
            diamond_count += 1
        count_max_diamond(object.bottom, source, diamond_count)

    if object.left != -1 and object.left != source:
        print('Left')
        if object.element == 'D':
            diamond_count += 1
        print(diamond_count)
        count_max_diamond(object.left, source, diamond_count)

    if object.top != -1 and object.top != source:
        print('top')
        if object.element == 'D':
            diamond_count += 1
        count_max_diamond(object.top, source, diamond_count)

    if diamond_count > max_diamond:
        max_diamond = diamond_count

    if object.element == 'D':
        diamond_count -= 1
        return
    else:
        return


for object in object_list:
    count_max_diamond(object)

print(max_diamond)


